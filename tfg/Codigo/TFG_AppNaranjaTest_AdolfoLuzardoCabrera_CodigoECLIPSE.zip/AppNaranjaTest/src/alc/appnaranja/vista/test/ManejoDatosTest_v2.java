package alc.appnaranja.vista.test;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import alc.appnaranja.AppMediador;
import alc.appnaranja.modelo.Citas;
import alc.appnaranja.modelo.DatosCita;
import alc.appnaranja.modelo.Peluquerias;
import alc.appnaranja.vista.PrincipalVistaActivity;
import android.os.Bundle;
import android.test.ActivityInstrumentationTestCase2;
import android.util.Log;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;

@SuppressWarnings("unchecked")
public class ManejoDatosTest_v2 extends ActivityInstrumentationTestCase2<PrincipalVistaActivity> {
	
	private PrincipalVistaActivity vistaInicial;
	private AppMediador appMediador;
	private CountDownLatch contador;
	private String nombre = "Adolfo";
	private String telefono = "636175744";
	private String sexo = "Hombre";
	private String peluqueria = "Lanzarote";
	private String fecha = "23/03/2015";
	private String hora = "10:00";
	private String id_cita = fecha+hora+nombre;
	private String id_horario = fecha+hora;
	private DatosCita datosCita = new DatosCita(id_cita, id_horario, nombre, telefono, sexo);
	
	

	public ManejoDatosTest_v2() {
		super(PrincipalVistaActivity.class);
			
	}

	@Override
	protected void setUp() throws Exception {
		super.setUp();
		setActivityInitialTouchMode(false);
		vistaInicial = this.getActivity(); // se usa para crear la vista que crea el mediador
		appMediador = (AppMediador)vistaInicial.getApplication(); // se recupera el mediador
		contador = new CountDownLatch(1); // se usa para saber cuando ha terminado el proceso
		
	}

	// test de pedir una cita y comprobar si se guarda
	public void testPedirCita() throws Exception {

		esperarRespuesta();

		Citas.insertarCita(datosCita);

		Thread.sleep(5000);
		//obtengo la lista de las citas del usuario
		String id_usuario = telefono;
		Citas.obtenerListaCitas(id_usuario);

		contador.await(600000000, TimeUnit.MILLISECONDS);
		
	}
	
	// test cargar lista peluquerias
		public void testPeluquerias() throws Exception {
		
			esperarRespuesta();
			
			Peluquerias.obtenerListaPeluquerias();

			contador.await(600000000, TimeUnit.MILLISECONDS);
			
	
		}
		
		
	
	
	

	private void esperarRespuesta() throws Exception {
		// receptor que escucha la llegada de la lista con las citas del usuario
		BroadcastReceiver receptorDatos = new BroadcastReceiver() {
			@Override
			public void onReceive(Context contexto, Intent intent) {

					
					if (intent.getAction().equals(AppMediador.AVISO_LISTA_CITAS)) {
	
						Bundle extras = intent.getExtras();
						ArrayList<String> listaCitas = new ArrayList<String>();
						if (intent.getExtras() != null) {
							listaCitas = (ArrayList<String>)extras.getSerializable(AppMediador.DATOS_LISTA_CITAS);
							//Se comprueba que existe la cita que se acaba de a�adir
							assertTrue(listaCitas.contains(id_cita));

							if (listaCitas.contains(id_cita)){
								// se ha insertado, por lo que se va a recuperar el dato para ver si se ha hecho bien
							
								comprobarCita();
								appMediador.unRegisterReceiver(this);
								// el proceso ha terminado, por lo que se decrementa el contador
								contador.countDown(); 
								
								
							}else{
								fail("Error de inserci�n");
							}	
						}
						
					}
					
					if (intent.getAction().equals(AppMediador.AVISO_LISTA_PELUQUERIAS)) {

						Bundle extras = intent.getExtras();
						ArrayList<String> listaPeluquerias = new ArrayList<String>();
						if (intent.getExtras() != null) {
							listaPeluquerias = (ArrayList<String>)extras.getSerializable(AppMediador.DATOS_LISTA_PELUQUERIAS);
							assertTrue(listaPeluquerias.contains(peluqueria));
							appMediador.unRegisterReceiver(this);
							// el proceso ha terminado, por lo que se decrementa el contador
							contador.countDown(); 
							
							
							
						}
						
					}
			}
		};
		Log.v("adolfo", "se regista");
		// se registran las notificaciones
		appMediador.registerReceiver(receptorDatos, new String[]{AppMediador.AVISO_LISTA_CITAS, AppMediador.AVISO_LISTA_PELUQUERIAS});
		
	}
	
   // este metodo comprueba si los datos de la cita son correctos (comparando los datos locales con los que le llegan de la base de datos)

	private void comprobarCita() {

		try {
			// se accede a la base de datos para recuperar todos los registros
			@SuppressWarnings("rawtypes")
			ParseQuery query = new ParseQuery(Citas.nombreTabla);
			query.whereEqualTo(Citas.CAMPO_IDENTIFICADOR, id_cita);
			query.findInBackground(new FindCallback<ParseObject>() {

				@Override
				public void done(List<ParseObject> lista, ParseException e) {

					// si no ha habido error y la lista no est� vac�a (tiene que haber al menos 1 elemento, que corresponde
					// con el introducido en el m�todo testeado)
					if (e == null && lista != null) {

						// se crea una variable para guardar los datos que se reciben
						DatosCita datosCitaRecibidos = null;
						// y se almacenan
						for (ParseObject reg: lista) {
							datosCitaRecibidos = new DatosCita(reg.getString(Citas.CAMPO_IDENTIFICADOR), reg.getString(Citas.CAMPO_HORARIO), reg.getString(Citas.CAMPO_NOMBRE), reg.getString(Citas.CAMPO_TELEFONO), reg.getString(Citas.CAMPO_SEXO));
						}
						
						// se comprueban los resultados con el dato esperado.
						assertEquals( datosCitaRecibidos.getId_cita(), datosCita.getId_cita());
						assertEquals( datosCitaRecibidos.getId_horario(), datosCita.getId_horario());
						assertEquals( datosCitaRecibidos.getNombre(), datosCita.getNombre());
						assertEquals( datosCitaRecibidos.getSexo(), datosCita.getSexo());
						assertEquals( datosCitaRecibidos.getTelefono(), datosCita.getTelefono());
						
					} else {
						fail("Error en los datos insertados");
					}
					
					
				}
			});
			
		} catch (Exception e) {
		}	


 
}
	
	
	
	
	
	
}
