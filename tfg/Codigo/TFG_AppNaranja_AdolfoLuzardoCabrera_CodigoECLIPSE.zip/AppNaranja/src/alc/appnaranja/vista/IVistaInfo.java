package alc.appnaranja.vista;


public interface IVistaInfo {

	
}
