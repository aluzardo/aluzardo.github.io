package alc.appnaranja.presentador;

public interface IPresentadorAyuda {
	
	/**
	 * Se realizan todas las operaciones necesarias para mostrar la VistaAyuda.
	 */
	public void mostrarVistaAyuda();
	

}
