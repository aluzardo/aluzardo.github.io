package alc.appnaranja.presentador;


public class PresentadorInfo implements IPresentadorInfo {

	@Override
	public void mostrarVistaInfo() {
		
	}

	
	

}
