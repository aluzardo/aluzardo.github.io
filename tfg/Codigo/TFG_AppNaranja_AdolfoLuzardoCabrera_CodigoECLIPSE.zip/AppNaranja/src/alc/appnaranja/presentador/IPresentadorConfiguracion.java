package alc.appnaranja.presentador;

public interface IPresentadorConfiguracion {
	
	
	public void mostrarVistaConfiguracion();
	

}
