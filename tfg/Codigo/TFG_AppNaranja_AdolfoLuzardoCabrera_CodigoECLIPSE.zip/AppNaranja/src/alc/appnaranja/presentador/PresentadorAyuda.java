package alc.appnaranja.presentador;



public class PresentadorAyuda implements IPresentadorAyuda {

	@Override
	public void mostrarVistaAyuda() {
		
	}

	
	

}
