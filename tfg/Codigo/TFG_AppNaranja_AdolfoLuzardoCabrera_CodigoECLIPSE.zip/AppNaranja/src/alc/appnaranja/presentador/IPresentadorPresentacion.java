package alc.appnaranja.presentador;

public interface IPresentadorPresentacion {
	
	/**
	 * Se realizan todas las operaciones necesarias para mostrar la VistaPresentacion.
	 */
	public void mostrarVistaPresentacion();
	

}
