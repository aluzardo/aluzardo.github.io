package alc.appnaranja.presentador;


public class PresentadorConfiguracion implements IPresentadorConfiguracion {

	@Override
	public void mostrarVistaConfiguracion() {
		
	}

	
	

}
