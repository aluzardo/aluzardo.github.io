package alc.appnaranja.presentador;

public interface IPresentadorInfo {
	
	/**
	 * Se realizan todas las operaciones necesarias para mostrar la VistaInfo.
	 */
	public void mostrarVistaInfo();
	

}
